## arcanist

**Maintainer:** [@emzar](https://github.com/emzar)

This plugin adds many useful aliases.
