local pluginmanager = {
  "neoclide/coc.nvim", branch = 'release'
}

local cmp = {
  "hrsh7th/nvim-cmp", -- The completion plugin
  "hrsh7th/cmp-buffer", -- buffer completions
  -- "hrsh7th/cmp-path", -- path completions
  "hrsh7th/cmp-cmdline", -- cmdline completions
  "saadparwaiz1/cmp_luasnip", -- snippet completions
  "hrsh7th/cmp-nvim-lsp",
  "hrsh7th/cmp-nvim-lua",
  "SirVer/ultisnips",
  "jayli/vim-easycomplete",
  "hiphish/rainbow-delimiters.nvim",
}

local completion = {
  "valloric/youcompleteme",
  "honza/vim-snippets",
}

local snippets = {
  "hrsh7th/cmp-vsnip",    -- { name = 'vsnip' }
  "hrsh7th/vim-vsnip",
  "L3MON4D3/LuaSnip", --snippet engine
  "rafamadriz/friendly-snippets", -- a bunch of snippets to use
}

local language = {
  "vim-scripts/taglist.vim",
  'b4winckler/vim-objc',
  "keith/swift.vim",
  "octol/vim-cpp-enhanced-highlight",
  "vim-scripts/indentpython.vim",
}

local lsp = {
  "neovim/nvim-lspconfig", -- enable LSP
  -- "williamboman/mason.nvim", -- simple to use language server installer
  "mason-org/mason-lspconfig.nvim",-- simple to use language server installeri
  "tamago324/nlsp-settings.nvim", -- language server settings defined in json for
  -- "nvimtools/none-ls.nvim", -- LSP diagnostics and code actions {}
  "onsails/lspkind-nvim",
}

local formater = {
  "jay-babu/mason-null-ls.nvim",
  "jay-babu/mason-nvim-dap.nvim",
}

local debugger = {
  "mfussenegger/nvim-dap",
  "sakhnik/nvim-gdb",
  { 
    "rcarriga/nvim-dap-ui", 
    dependencies = {
      "mfussenegger/nvim-dap", 
      "nvim-neotest/nvim-nio"
    }
  }
}

local telescope = {
  "nvim-telescope/telescope.nvim",
  "nvim-telescope/telescope-media-files.nvim",
  "nvim-telescope/telescope-frecency.nvim",
}

local treesitter = {
  "nvim-treesitter/nvim-treesitter",
  "nvim-treesitter/nvim-treesitter-context",
}

local comment = {
  "numToStr/Comment.nvim", -- Easily comment stuff
  "JoosepAlviste/nvim-ts-context-commentstring",
  "folke/todo-comments.nvim",
}

local git = {
  "lewis6991/gitsigns.nvim",
}

local tree = {
  "nvim-tree/nvim-web-devicons",
  -- "kyazdani42/nvim-tree.lua",
  "scrooloose/nerdtree",
  "nvim-neo-tree/neo-tree.nvim",
}

local bufferline = {
  "akinsho/bufferline.nvim",
  "moll/vim-bbye",
}

local terminal = {
  "akinsho/toggleterm.nvim",
}

local project = {
  "ahmedkhalf/project.nvim",
}

local whichkey = {
  "folke/which-key.nvim",
}

local navi = {
  "christoomey/vim-tmux-navigator",
  "tpope/vim-surround",
  "felipec/vim-sanegx",
}

local other = {
  "nvim-lua/plenary.nvim", -- Useful lua functions used ny lots of plugins
  "ThePrimeagen/harpoon",
  "windwp/nvim-autopairs", -- Autopairs, integrates with both cmp and treesitter
  "nvim-lualine/lualine.nvim",
  "lewis6991/impatient.nvim",
  "lukas-reineke/indent-blankline.nvim",
  "antoinemadec/FixCursorHold.nvim", -- This is needed to fix lsp doc highlight
}

local utils = {
  "phaazon/hop.nvim",
  "tpope/vim-repeat",
  "tpope/vim-surround",
}

local ai = {
  {
    'luozhiya/fittencode.nvim',
    config = function()
      require('fittencode').setup()
    end,
  }
}

return {
  pluginmanager,
  cmp,
  snippets,
  language,
  lsp,
  formater,
  debugger,
  telescope,
  treesitter,
  comment,
  git,
  tree,
  terminal,
  project,
  whichkey,
  other,
  utils,
  ai,
}
