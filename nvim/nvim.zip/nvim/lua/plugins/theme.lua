return {
  { 
    "ellisonleao/gruvbox.nvim", 
    lazy = true,
    opts = { 

    }
  },
  { "catppuccin/nvim", lazy = true }, 
  { "glepnir/zephyr-nvim", lazy = true },
  { "shaunsingh/nord.nvim", lazy = true },
  { "folke/tokyonight.nvim", lazy = true },
  { "rebelot/kanagawa.nvim", lazy = true },
  { "jacoborus/tender.vim", lazy = true },
  { "nyoom-engineering/nyoom.nvim", lazy = true },
  { "nyoom-engineering/oxocarbon.nvim", lazy = true },
  { "savq/melange-nvim", lazy = true },
  { "luisiacc/gruvbox-baby", lazy = true },
  { "folke/styler.nvim", lazy = true },
  { "dasupradyumna/midnight.nvim", lazy = true },
  { "lunarvim/Onedarker.nvim", lazy = true },
  { "neanias/everforest-nvim", lazy = true },
  { "cpea2506/one_monokai.nvim", lazy = true },
  { "navarasu/onedark.nvim", lazy = true },

  -- Configure LazyVim to load gruvbox
  -- {
  --   "LazyVim/LazyVim",
  --   opts = {
  --     colorscheme = "gruvbox",
  --   },
  -- },
}