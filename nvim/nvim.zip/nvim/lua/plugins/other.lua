return {
  { "tpope/vim-surround" },
  { "christoomey/vim-tmux-navigator" },
  { "akinsho/toggleterm.nvim", version = "*", config = true},
  -- markdown support
  { "godlygeek/tabular" }, -- required by vim-markdown
  { "plasticboy/vim-markdown" },
  { "NvChad/nvim-colorizer.lua" },
  { "voldikss/vim-floaterm" },
  { "hrsh7th/cmp-cmdline" },
  -- { "L3MON4D3/LuaSnip" }, 
  -- { "saadparwaiz1/cmp_luasnip" },
  -- { "SirVer/ultisnips" },
  -- { "quangnguyen30192/cmp-nvim-ultisnips" },
  -- { "dcampos/nvim-snippy" },
  -- { "dcampos/cmp-snippy" },
}
