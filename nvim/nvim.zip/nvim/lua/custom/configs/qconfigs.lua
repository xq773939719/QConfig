local qconfigs = {
  
}

return qconfigs