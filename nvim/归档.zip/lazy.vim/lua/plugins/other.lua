return {
  { "tpope/vim-surround" },
  { 'christoomey/vim-tmux-navigator' },
  {'akinsho/toggleterm.nvim', version = "*", config = true},
}
