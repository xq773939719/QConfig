return {
  { 
    "ellisonleao/gruvbox.nvim", 
    lazy = true,
    opts = { 

    }
  },
  { "catppuccin/nvim", name = "catppuccin", priority = 1000 },
  { "glepnir/zephyr-nvim", lazy = true },
  { "shaunsingh/nord.nvim", lazy = true },
  { "folke/tokyonight.nvim", lazy = true },
  { "rebelot/kanagawa.nvim", lazy = true },
  { "jacoborus/tender.vim", lazy = true },
  { "nyoom-engineering/nyoom.nvim", lazy = true },
  { "nyoom-engineering/oxocarbon.nvim", lazy = true },
  { "savq/melange-nvim", lazy = true },
  { "luisiacc/gruvbox-baby", lazy = true },
  { "folke/styler.nvim", lazy = true },
  { "dasupradyumna/midnight.nvim", lazy = true },
  { "lunarvim/Onedarker.nvim", lazy = true },
  { "neanias/everforest-nvim", lazy = true },
  { "cpea2506/one_monokai.nvim", lazy = true },
  { "navarasu/onedark.nvim", lazy = true },
  { "sainnhe/edge", lazy = true },
  { "sainnhe/sonokai", lazy = true },
  { "sainnhe/gruvbox-material", lazy = true },
  { "sainnhe/sonokai", lazy = true },
  { "projekt0n/github-nvim-theme", lazy = true },

  { 
    "xiyaowong/transparent.nvim", 
    groups = { -- table: default groups
      'Normal', 'NormalNC', 'Comment', 'Constant', 'Special', 'Identifier',
      'Statement', 'PreProc', 'Type', 'Underlined', 'Todo', 'String', 'Function',
      'Conditional', 'Repeat', 'Operator', 'Structure', 'LineNr', 'NonText',
      'SignColumn', 'CursorLineNr', 'EndOfBuffer',
    },
    extra_groups = {}, -- table: additional groups that should be cleared
    exclude_groups = {}, -- table: groups you don't want to clear
  },

  -- Configure LazyVim to load gruvbox

  -- {
  --   "LazyVim/LazyVim",
  --   opts = {
  --    colorscheme = "catppuccin",
  --   },
  -- },
}
