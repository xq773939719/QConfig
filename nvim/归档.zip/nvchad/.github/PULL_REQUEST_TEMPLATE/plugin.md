(Make sure your title is either: 'fix', 'chore', or 'feat' then your title. ex: `fix: add new plugin`)

Fixes Issue # (If it doesn't fix an issue then delete this line)

Plugins Added:
- [Plugin Name](Plugin Link)
- [Plugin Name](Plugin Link)

Reasoning:
List why the plugin(s) should be added

Speed:
Show the impact on the speed of nvChad

Other:
Anything else relevant goes here
