local options = {
  ensure_installed = { "lua" },

  highlight = {
    enable = true,
    use_languagetree = true,
  },
  rainbow = {
    enable = true
  },

  indent = { enable = true },
}

return options
