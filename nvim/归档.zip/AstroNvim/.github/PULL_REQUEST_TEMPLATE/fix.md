Fixes Issue # (If it doesn't fix an issue then delete this line)

Bugs Fixed:
- A bullet for each bug fixed and a description

Other:
Anything else relevant goes here
